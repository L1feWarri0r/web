<!DOCTYPE html>
<html lang="en">

<head>

    <title>Srijan vidhyapeeth</title>
    <link href="school_activities.css" rel="stylesheet" type="text/css">

    <header>
        <div class="nav_up">
            <nav>
                <ul>
                <li><a href="/myproject/new/index.php"class="up_nav">LOGOUT</a></li>
                <li><a href="/myproject/new/gallary.php" class="d_nav">PHOTOGALLARY</a></li>
               <li><a href="/myproject/new/faqs.php" class="up_nav">FAQs</a></li>
               <li><a href="/myproject/new/feedback.php" class="up_nav">FEEDBACK</a></li>
               <li><a href="/myproject/new/downloads.php"class="up_nav">DOWNLOADS</a></li>
                </ul>
            </nav>
        </div>
        <div class="upp_nav"></div>
        <div class="heading">
            <img src="logo.png" alt="Srijan logo" class="logo">
            <div class="school_name"><b>SRIJAN VIDYAPEETH</b></div>
            <img src="img1.jpg" alt="image" class="image_header">
        </div>
        <div class="down_nav"></div>
    </header>
</head>

<body>
    <div class="main_menu">
        <nav>
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/main_about.php'" class="dropbtn">ABOUT US</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/history.php">HISTORY</a>
                 <a href="/myproject/new/vision.php">VISION & MISSION</a>
                 <a href="/myproject/new/management.php">MANAGEMENT</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_education.php'" class="dropbtn">SCHOOL EDUCATION</button>
              <div class="dropdown-content">
              <a href="/myproject/new/school_about.php">ABOUT US</a>
                 <a href="/myproject/new/features.php">FEATURES</a>
                 <a href="/myproject/new/courses.php">COURSES & SCHEMES</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
                 <a href="/myproject/new/faculty.php">FACULTY &STAFFS</a>
                 <a href="/myproject/new/school_activities.php">SCHOOL ACTIVITIES</a>
                 <a href="/myproject/new/school_admissions.php">ADMISSIONS</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
                 <a href="/myproject/new/contact.php">CONTACT US</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/higher_education.php'" class="dropbtn">HIGHER EDUCATION</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/calender.php">ACADEMIC CALENDERS</a>
                 <a href="/myproject/new/ug.php">UG PROGRAMMES</a>
                 <a href="/myproject/new/pg.php">PG PROGRAMMES</a>
                 <a href="/myproject/new/phd.php">PH.D. PROGRAMMES</a>
                 <a href="/myproject/new/certificate.php">CERTIFICATE & DIPLOMA PROGRAMMES</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
              </div>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_admissions.php'" class="dropbtn">ADMISSIONS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/school_education.php">SCHOOL EDUCATION</a>
                 <a href="/myproject/new/higher_education.php">HIGHER EDUCATION</a>
                 <a href="/myproject/new/rule.php">CAMPUS RULES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/finance.php'" class="dropbtn">FINANCIAL ASSISTANCE</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/scholar.php">SCHOLARSHIPS</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/library.php'" class="dropbtn">LIBRARY</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/lib.php">LIBRARY</a>
                 <a href="/myproject/new/online.php">ONLINE RESOURCES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/exam.php'" class="dropbtn">EXAMINATION</button>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/sports.php'" class="dropbtn">SPORTS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/indoor.php">INDOOR</a>
                 <a href="/myproject/new/outdoor.php">OUTDOOR</a>
              </div>
           </div>
        
        </nav>
  
     </div>
  
     
    <div class="main_content">
       <h2> School Activities</h2>
     
       <p>
        <b>Major School Activities –</b> The School firmly believes that textual studies are only but a part of the full development of a child and therefore provides a spectrum of in house activities through its program of panchmukhi shiksha. The main thrust of activities at the Vidyapith are visualized to promote the development of a balanced and harmonious personality of the students including physical, practical, aesthetic, moral and intellectual aspects.
    </p>  <img src="yoga.jpg" alt="yoga image" class="yoga">


<h4>Engagement with local community -</h4>
<div class="para">
    1. We run an adult education center where we engage the mothers of the students coming from Banasthali Village and teach them to prepare low cost and no cost materials. They are taught to prepare useful items like carpet, doormats, bags, shoes, wall hangings etc out of felt (Nanda) and waste materials. They are also taught  to prepare food items like mongodi, papad, pickle, Sauce, Murbba, amla candies and snacks. This learning provides them a source of income.<br><br>
    2. The department of Home Science, in school is a window of expertise and awareness in health, nutrition, and therapeutic dietary management of personality for the local community.<br><br></div>
    <p class="p_h"> The activities are diverse and help villagers in childcare & nourishment, processing and preservation of food ,dress designing and tailoring.</p>

 <img src="sport team.jpg" alt="yoga image" class="yoga">
 <div class="para1">
 1. The girl guide students are involved in community services through activities related to health, environment and informal education. We conduct health programme from time to time which includes bone densitometry (Osteoporosis),  Checkup Camp for eyes, bronchial asthma, allergic rhinitis cough,  hemoglobin testing As it is a girls’ institution  we run a separate  boys school meant only for the wards of the surrounding villages and provide them a quality education with all modern  physical infrastructure.<br><br>
 2. We have a community F.M. Radio station known as Radio Banasthali to broadcast all awareness programme on health, food, clothing, agriculture, cleanliness and agriculture. The programs are prepared and presented by the senior students of the school.
</div>

    </div>
</body>

</html>