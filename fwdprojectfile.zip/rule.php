<!DOCTYPE html>
<html lang="en">

<head>

    <title>Srijan vidhyapeeth</title>
    <link href="rules.css" rel="stylesheet" type="text/css">

    <header>
        <div class="nav_up">
            <nav>
                <ul>
                <li><a href="/myproject/new/index.php"class="up_nav">LOGOUT</a></li>
                <li><a href="/myproject/new/gallary.php" class="d_nav">PHOTOGALLARY</a></li>
               <li><a href="/myproject/new/faqs.php" class="up_nav">FAQs</a></li>
               <li><a href="/myproject/new/feedback.php" class="up_nav">FEEDBACK</a></li>
               <li><a href="/myproject/new/downloads.php"class="up_nav">DOWNLOADS</a></li>
                </ul>
            </nav>
        </div>
        <div class="upp_nav"></div>
        <div class="heading">
            <img src="logo.png" alt="Srijan logo" class="logo">
            <div class="school_name"><b>SRIJAN VIDYAPEETH</b></div>
            <img src="img1.jpg" alt="image" class="image_header">
        </div>
        <div class="down_nav"></div>
    </header>
</head>

<body>
    <div class="main_menu">
        <nav>
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/main_about.php'" class="dropbtn">ABOUT US</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/history.php">HISTORY</a>
                 <a href="/myproject/new/vision.php">VISION & MISSION</a>
                 <a href="/myproject/new/management.php">MANAGEMENT</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_education.php'" class="dropbtn">SCHOOL EDUCATION</button>
              <div class="dropdown-content">
              <a href="/myproject/new/school_about.php">ABOUT US</a>
                 <a href="/myproject/new/features.php">FEATURES</a>
                 <a href="/myproject/new/courses.php">COURSES & SCHEMES</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
                 <a href="/myproject/new/faculty.php">FACULTY &STAFFS</a>
                 <a href="/myproject/new/school_activities.php">SCHOOL ACTIVITIES</a>
                 <a href="/myproject/new/school_admissions.php">ADMISSIONS</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
                 <a href="/myproject/new/contact.php">CONTACT US</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/higher_education.php'" class="dropbtn">HIGHER EDUCATION</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/calender.php">ACADEMIC CALENDERS</a>
                 <a href="/myproject/new/ug.php">UG PROGRAMMES</a>
                 <a href="/myproject/new/pg.php">PG PROGRAMMES</a>
                 <a href="/myproject/new/phd.php">PH.D. PROGRAMMES</a>
                 <a href="/myproject/new/certificate.php">CERTIFICATE & DIPLOMA PROGRAMMES</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
              </div>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_admissions.php'" class="dropbtn">ADMISSIONS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/school_education.php">SCHOOL EDUCATION</a>
                 <a href="/myproject/new/higher_education.php">HIGHER EDUCATION</a>
                 <a href="/myproject/new/rule.php">CAMPUS RULES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/finance.php'" class="dropbtn">FINANCIAL ASSISTANCE</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/scholar.php">SCHOLARSHIPS</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/library.php'" class="dropbtn">LIBRARY</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/lib.php">LIBRARY</a>
                 <a href="/myproject/new/online.php">ONLINE RESOURCES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/exam.php'" class="dropbtn">EXAMINATION</button>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/sports.php'" class="dropbtn">SPORTS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/indoor.php">INDOOR</a>
                 <a href="/myproject/new/outdoor.php">OUTDOOR</a>
              </div>
           </div>
         
        </nav>
  
     </div>
  
     
    <div class="main_content">
       <h2>CAMPUS RULES </h2>
       <br><br><strong>
       ACADEMIC, CAMPUS AND HOSTEL RULES<br></strong><br><br>
       <p><ul class= "faculty_members">
       <li> Academic activities of the students will be strictly guided by the Academic rules and decisions taken by Academic Bodies from time to time.<br>
<li> Admission of married students shall not be possible in any other courses except the postgraduate courses.</li>
<li> In post-graduate courses too, on very special circumstances only, the married students will be provided admission. After being admitted to a courses, if a student gets married before attaining the age of 18 years, her admission shall be canceled from the Vidyapith.</li>
<li> Admission will be open to all women irrespective of their race, religion, caste, colour or domicile.</li>
<li> Every student seeking admission to Banasthali shall submit an application on the prescribed form and pay the requisite fee by the prescribed date.</li>
<li> Under extra ordinary circumstances the Vice-Chancellor, with the approval of the President, can relax any condition except the minimum eligibility, but all such cases will have to be placed before the Executive Council for concurrence.</li></ul>
</p>

<br><strong>
Campus and Hostel Rules :<br></strong><br>
       <p><b>
       Limited seats are available for the students of Banasthali Vidyapith. At Banasthali it is 
     Mandatory to take admission in hostel for all the students except those residing with their guardians in
     Vidyapith Campus.<br>
     Important Information regarding application form<br>
     <ul class= "faculty_members1">
   <li> "Father" will be treated as natural guardian. In case of married students "Husband" will be 
         treated as guardian. In case of any other person  being the guardian,  clarification of the
         same must be provided. University reserves  the  right for its acceptability. No person
         will be accepted as Local guardian by rule. The Chief warden of hostels is local guardian
         for all the students.<br></li>

   <li> For any query regarding admission you must quote the Application form Number, Name and
       the course applied for.<br><br></li></ul></b>
       <ul class= "faculty_members1">
       <li> All the hostels of Vidyapith come under "Shri Shantabai Shiksha Kuteer" for management purpose.</li>

<li> Application form for hostel admission must be sent alongwith the admission form.</li>

<li> A student will be admitted in hostel only after getting regular admission in a class.</li>

<li> Final admission will be only given after medical examination by the Medical Officer and after depositing proper fee and approval of Chief Warden thereafter.</li>

<li> Vice Chancellor, Banasthali Vidyapith reserves the right to refuse admission to the hostel without any reason whatsoever.</li>

<li> Vidyapith reserves the right to cancel the admission of any student after 3 weeks if the proper fees is not deposited by stipulated time.</li>

<li> Hostel reserves the right to refuse admission to those who are irregular in attendance or whose academic performance remained unsatisfactory in the previous year.</li>

<li> It is mandatory to follow the instructions of warden, Chief warden and the Vice Chancellor regarding monitoring the discipline otherwise it may cause termination from the hostels.</li>

<li>All the students should attend classes as well as practicals regularly. Absence from classes without prior permission may cause cancellation of admission from hostel except in case of illness.</li>

<li> It is collective as well as individual responsibility of the students to keep the hostel premises clean and healthy.</li>

<li> Students should not create any inconvenience to the other students of the hostel.</li>

<li> It is considered a very serious matter if a student encourages other students(s) to breach any of these rules.</li>

<li> Students must remain inside their rooms after the silence bell.</li>

<li> Cooking is not allowed in side the room.</li>

<li> Wearing dresses like night suit, night gown or dressing gown etc. is not allowed at Cafeteria or at the door/ outside hostels.</li>

<li> Electrical stove, emersion rod etc. are not permissible in the  hostel. Such equipment if found in the hostel room will be taken and will not be returned back.</li>

<li> Transistor, Radio, Tape recorder etc. may be used in the room subject to the no objection by other students. If it creates inconvenience it may be taken away and will be returned only at the time of leaving the hostel.</li>

<li> Use of jewelry and cosmetics is uncommon. Students should also not keep excess cash in their rooms. It should be kept in Bank account.</li>

<li> All the correspondence by the students should be through the hostel.</li>

<li> Students are not allowed to visit staff quarters as well as guest house without prior permission from hostels.</li>

<li> Breach of rules & regulations would cause termination from hostel and the decision of Vice Chancellor will be final in this regard which will have to be acceptable to the guardian as well as to the student.</li>
</p></ul>

<br><strong>
Cloths<br></strong><br>
<p>
<ul class= "faculty_members1">
<li> It is mandatory to wear Khadi in Banasthali Campus.</li>
<li> Khadi implies the hand woven cotton cloth certified by Khadi Gramodyog Commission.</li>
<li> It is advised to buy the uniform and Blazer (coat) from the Khadi Bhandar of Banasthali.</li>
<li> Students leaving their belonging in the hostels but do not turnup later must collect their belonging at least by  the end of the month of  October. After that their will be no responsibility of safe return of their Items.</li></ul>
</p>
</div>
</body>
</html>









 


 
  

    