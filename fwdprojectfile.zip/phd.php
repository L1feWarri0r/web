<!DOCTYPE html>
<html lang="en">

<head>

    <title>Srijan vidhyapeeth</title>
    <link href="phd.css" rel="stylesheet" type="text/css">

    <header>
        <div class="nav_up">
            <nav>
                <ul>
                <li><a href="/myproject/new/index.php"class="up_nav">LOGOUT</a></li>
                <li><a href="/myproject/new/gallary.php" class="d_nav">PHOTOGALLARY</a></li>
               <li><a href="/myproject/new/faqs.php" class="up_nav">FAQs</a></li>
               <li><a href="/myproject/new/feedback.php" class="up_nav">FEEDBACK</a></li>
               <li><a href="/myproject/new/downloads.php"class="up_nav">DOWNLOADS</a></li>
                </ul>
            </nav>
        </div>
        <div class="upp_nav"></div>
        <div class="heading">
            <img src="logo.png" alt="Srijan logo" class="logo">
            <div class="school_name"><b>SRIJAN VIDYAPEETH</b></div>
            <img src="img1.jpg" alt="image" class="image_header">
        </div>
        <div class="down_nav"></div>
    </header>
</head>

<body>
    <div class="main_menu">
        <nav>
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/main_about.php'" class="dropbtn">ABOUT US</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/history.php">HISTORY</a>
                 <a href="/myproject/new/vision.php">VISION & MISSION</a>
                 <a href="/myproject/new/management.php">MANAGEMENT</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_education.php'" class="dropbtn">SCHOOL EDUCATION</button>
              <div class="dropdown-content">
              <a href="/myproject/new/school_about.php">ABOUT US</a>
                 <a href="/myproject/new/features.php">FEATURES</a>
                 <a href="/myproject/new/courses.php">COURSES & SCHEMES</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
                 <a href="/myproject/new/faculty.php">FACULTY &STAFFS</a>
                 <a href="/myproject/new/school_activities.php">SCHOOL ACTIVITIES</a>
                 <a href="/myproject/new/school_admissions.php">ADMISSIONS</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
                 <a href="/myproject/new/contact.php">CONTACT US</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/higher_education.php'" class="dropbtn">HIGHER EDUCATION</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/calender.php">ACADEMIC CALENDERS</a>
                 <a href="/myproject/new/ug.php">UG PROGRAMMES</a>
                 <a href="/myproject/new/pg.php">PG PROGRAMMES</a>
                 <a href="/myproject/new/phd.php">PH.D. PROGRAMMES</a>
                 <a href="/myproject/new/certificate.php">CERTIFICATE & DIPLOMA PROGRAMMES</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
              </div>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_admissions.php'" class="dropbtn">ADMISSIONS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/school_education.php">SCHOOL EDUCATION</a>
                 <a href="/myproject/new/higher_education.php">HIGHER EDUCATION</a>
                 <a href="/myproject/new/rule.php">CAMPUS RULES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/finance.php'" class="dropbtn">FINANCIAL ASSISTANCE</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/scholar.php">SCHOLARSHIPS</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/library.php'" class="dropbtn">LIBRARY</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/lib.php">LIBRARY</a>
                 <a href="/myproject/new/online.php">ONLINE RESOURCES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/exam.php'" class="dropbtn">EXAMINATION</button>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/sports.php'" class="dropbtn">SPORTS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/indoor.php">INDOOR</a>
                 <a href="/myproject/new/outdoor.php">OUTDOOR</a>
              </div>
           </div>
        </nav>
     </div>
    <div class="main_content">
       <h2>P.H.D. Programmes</h2>
       <p>
       Research Entrance Test (RET) for admission to Ph.D. program in Banasthali Vidyapith
<br><br><strong>
RESEARCH PROGRAMME (Ph.D.)<br> Subjects in which Research facility is available</strong>
<br><br>
1.    Computer Science<br>
2.    Pharmacy<br>
3.    Chemistry<br>
4.    Chemical Engineering<br>
5.    Bio-science and  Biotechnology<br>
<br><br><strong>Bye-Laws related to Research Programme for the award of Ph.D Degree</strong>
<br><br><b>14(HE)
<br><br></b><b>
C.1. (1)</b><br><br>
A Ph.D. Aspirant who has obtained a Master's degree in the subject or related /allied area with at least 55% aggregate marks (or an equivalent CGPA) (50% in case of SC/ST/ Differently-Abled category) or has qualified the National Eligibility Test (NET) conducted by the University Grants commission may apply for Admission to the Ph.D. programme at any time during the academic year for pursuing his/her research work under the guidance of a supervisor approved by the Vidyapith. A candidate who has a minimum 5 years of work experience (Teaching/ Industrial/ Research) may be given relaxation of 5% in the marks by the Vice-Chancellor/Pro Vice-Chancellor for registration to the Ph.D. programme. Every candidate has to appear in the Research Entrance Test (RET) except for the subject of Fine Arts, Visual Art, Music, Dance & Design. Qualifying RET is a mandatory requirement for enrollment and until that stage the admission shall be treated as provisional.
<br>Note: A Ph.D. Aspirant who has qualified NET, SLET, GATE, GPAT or M.Phil (admitted to M.Phil.  programme through entrance examination) may be exempted from the research entrance test. M.Phil candidates shall also be exempted from course work.<br><br><b>

C.1. (2)</b><br><br>
The following persons may be considered eligible to act as research supervisors of the Vidyapith:<br>

(a)    Any Professor or Associate Professor of the Vidyapith with at least five research publications<br>

(b)   Any Assistant Professor with a Ph.D. degree and at least two research publications may also be recognized as Research Supervisor subject to approval by Research Board.<br>

(c) External members of the Executive Council/Academic Council/Research Board.<br>

(d) Any other person with Ph.D. degree deemed fit by the research board to supervise Ph.D. work of student.<br>

(e) Eminent academicians with at least fifteen years' teaching experience (not below degree classes) and independent research publications equivalent to Ph.D. work may also be recognized as Research Supervisor subject to approval by Research Board.
<br><br><br><b>

C.1. (3) </b><br><br>
A candidate may work under joint supervision of two (approved) research supervisors. The supervisors are not necessarily required to belong to the same faculty/subject.<br><br><br><b>

C.1. (4) </b><br><br>
No persons will be allowed to guide his/her close relations. The term ‘close relation' includes wife, husband, son, daughter, grand-son, grand-daughter, brother, sister, nephew, niece, grand-niece, grand-nephew, uncle, aunt, son in law, daughter in law.
<br><br><br><b>

C.1. (5) </b><br><br>
A candidate shall be treated as duly enrolled for the Ph.D. programme only after it is verified that he/she meets the eligibility criteria, has qualified RET, and has submitted migration certificate of the University from which he/she completed his/her Master's degree or a professional degree declared equivalent to masters degree. Candidates who have already been enrolled once in the Vidyapith shall be issued the same enrollment number automatically on the submission of the migration certificate.

   </p>
   </div>
</body>

</html>

 








 

























 

 

 



