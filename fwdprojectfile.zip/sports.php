<!DOCTYPE html>
<html lang="en">

<head>

    <title>Srijan vidhyapeeth</title>
    <link href="sport.css" rel="stylesheet" type="text/css">

    <header>
        <div class="nav_up">
            <nav>
                <ul>
                <li><a href="/myproject/new/index.php"class="up_nav">LOGOUT</a></li>
                <li><a href="/myproject/new/gallary.php" class="d_nav">PHOTOGALLARY</a></li>
               <li><a href="/myproject/new/faqs.php" class="up_nav">FAQs</a></li>
               <li><a href="/myproject/new/feedback.php" class="up_nav">FEEDBACK</a></li>
               <li><a href="/myproject/new/downloads.php"class="up_nav">DOWNLOADS</a></li>
                </ul>
            </nav>
        </div>
        <div class="upp_nav"></div>
        <div class="heading">
            <img src="logo.png" alt="Srijan logo" class="logo">
            <div class="school_name"><b>SRIJAN VIDYAPEETH</b></div>
            <img src="img1.jpg" alt="image" class="image_header">
        </div>
        <div class="down_nav"></div>
    </header>
</head>

<body>
    <div class="main_menu">
        <nav>
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/main_about.php'" class="dropbtn">ABOUT US</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/history.php">HISTORY</a>
                 <a href="/myproject/new/vision.php">VISION & MISSION</a>
                 <a href="/myproject/new/management.php">MANAGEMENT</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_education.php'" class="dropbtn">SCHOOL EDUCATION</button>
              <div class="dropdown-content">
              <a href="/myproject/new/school_about.php">ABOUT US</a>
                 <a href="/myproject/new/features.php">FEATURES</a>
                 <a href="/myproject/new/courses.php">COURSES & SCHEMES</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
                 <a href="/myproject/new/faculty.php">FACULTY &STAFFS</a>
                 <a href="/myproject/new/school_activities.php">SCHOOL ACTIVITIES</a>
                 <a href="/myproject/new/school_admissions.php">ADMISSIONS</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
                 <a href="/myproject/new/contact.php">CONTACT US</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/higher_education.php'" class="dropbtn">HIGHER EDUCATION</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/calender.php">ACADEMIC CALENDERS</a>
                 <a href="/myproject/new/ug.php">UG PROGRAMMES</a>
                 <a href="/myproject/new/pg.php">PG PROGRAMMES</a>
                 <a href="/myproject/new/phd.php">PH.D. PROGRAMMES</a>
                 <a href="/myproject/new/certificate.php">CERTIFICATE & DIPLOMA PROGRAMMES</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
              </div>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_admissions.php'" class="dropbtn">ADMISSIONS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/school_education.php">SCHOOL EDUCATION</a>
                 <a href="/myproject/new/higher_education.php">HIGHER EDUCATION</a>
                 <a href="/myproject/new/rule.php">CAMPUS RULES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/finance.php'" class="dropbtn">FINANCIAL ASSISTANCE</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/scholar.php">SCHOLARSHIPS</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/library.php'" class="dropbtn">LIBRARY</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/lib.php">LIBRARY</a>
                 <a href="/myproject/new/online.php">ONLINE RESOURCES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/exam.php'" class="dropbtn">EXAMINATION</button>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/sports.php'" class="dropbtn">SPORTS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/indoor.php">INDOOR</a>
                 <a href="/myproject/new/outdoor.php">OUTDOOR</a>
              </div>
           </div>
        </nav>
     </div>  
    <div class="main_content">
       <h2>Sports</h2>
       <br><br><strong>
       Games and Sports:<br></strong>
        <p>Inter-faculty/ Inter house competitions are few of the important events in the intramural programme. The intramural programme is formally opened every year with a festive look. It is represented by all the faculties of the Vidyapith and houses of the Higher Secondary  and Primary schools. All the teams assemble at Vidula Maidan representing their faculty/ houses projecting some contemporary political , cultural & social issues in a colorful procession.<br><br>

        With the opening ceremony of intramurals, the year long inter-faculty/ house competition takes off. The intramural competitions are organized in approximately 15-20 games according to the time and facilities available. These competitions are organized through out the session . A formal valedictory function is organized to declare the winner faculty/ house of year and to conclude the year long intramural programme.</p>

        <br><br><strong>
        Intramural Programmes :<br></strong>
        <p>Intramural activities consist of all the sport and fitness activities carried on inside the campus of routine. The morning fitness programme for the masses, which starts at 6.00 a.m. in summer & 6.30 a.m. in winter includes Yogasans, Marshal Arts, Conditioning and Fitness exercise, and Aerobics. All these activities are carried out simultaneously at different stations at Vidula Maidan . Students join various activities according to their interest & choice.<br><br>
        The evening programme at Vidula Maidan starts at 4.30 pm. which includes match practice for various games like Basketball, Volleyball, Athletics, Hockey, Football, Tennis, Marshal Arts, Kho-Kho, Kabaddi, Handball, Netball, Softball, Archery, Cricket & Swimming (Seasonal). Match Practice sessions are for the preparation of the teams for extramural competitions.
        </p>
         <img src="badminton.jpg" alt="image" class="imagek">
         <img src="chesh.jpg" alt="image" class="imagek">  
         <img src="swimming.jpeg" alt="image" class="imagek"> <br><br>
         <img src="tabletenis.jpg" alt="image" class="imagek">
         <img src="basketball.jpeg" alt="image" class="imagek">  
         <img src="volleyball.jpg" alt="image" class="imagek"> 
</div>
</body>
</html>







