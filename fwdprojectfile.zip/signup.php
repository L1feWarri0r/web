<?php
error_reporting(0);
$showAlert = false;
$login = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'configure.php';
    $UserName = $_POST["UserName"];
    $NewPassword=$_POST["NewPassword"];
    $ConfirmPassword = $_POST["ConfirmPassword"];
    $PersonName = $_POST["PersonName"];
    if($ConfirmPassword==$NewPassword)
   {  $sql = "INSERT INTO user (`PersonName`, `UserId`, `UserPassword`,`Time_Of_Register`)
    VALUES ('$PersonName','$UserName',MD5('$ConfirmPassword'),current_timestamp())"; 
        $result = mysqli_query($conn, $sql);
        if ($result){
            $showAlert = true;
            echo '<script type="text/JavaScript"> 
            alert("You have registered Successfully.");
            </script>';
             session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['UserName'] = $UserName;
            header("location: index.php");
        }
   }
   else
   {
    echo '<script type="text/JavaScript"> 
    alert("Password not matched");
    </script>';
   }
}
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Srijan vidhyapeeth</title>
<link href="sign.css" rel="stylesheet" type="text/css">
   

   <header>
      <div class="nav_up">
      </div>
      <div class="upp_nav"></div>
      <div class="heading">
         <img src="logo.png" alt="Srijan logo" class="logo">
         <div class="school_name"><b>SRIJAN VIDYAPEETH</b></div>
         <img src="img1.jpg" alt="image" class="image_header">
      </div>
      <div class="down_nav"></div>
   </header>
</head>
    <body>
        <form action="signup.php" method="post">

           <div class="reg_tit">
                <h2>Registered Yourself</h2>
            </div>
                    
                        <div class="enter">
                      <li><a href="index.php"class="btn_login">LOGIN</a></li>

        
                      <li><a href="signup.php"class="btn_login">SIGNUP</a></li>

                        </div>
                        <script>
                            const currentLocation=location.href;
                            const btnItem=document.querySelectorAll('a');
                            const btnLength=btnItem.length
                            for(let i=0;i<btnLength;i++)
                              {
                                   if(btnItem[i].href===currentLocation){
                                     btnItem[i].className="active"
                                        }
                              }
                        </script>
                        <div class="login">
                <div>
             <input type="text" name="PersonName"class="u" placeholder="Full Name">
                </div>
                <div class="user_image">

                </div>
                <div>
             <input type="email" name="UserName" class="u" placeholder="Email or Phone">
                </div>
                <div>
             <input type="password" name="NewPassword"class="u" placeholder="New password" >
                       </div>
                       <div>
             <input type="password" name="ConfirmPassword"class="u" placeholder="Confirm Password">
                           </div>
               
                <div>
             <button type="submit" class="log-in">Create An Account</button>
            </div>
    
        </form>
        <div class="image_slider">
    <img src="" id="image">
        
    <script src="welcome.js">
         </script>
 </div>
      
    </body>

</html>