<!DOCTYPE html>
<html lang="en">

<head>

   <title>Srijan vidhyapeeth</title>
   <link href="about.css" rel="stylesheet" type="text/css">

   <header>
      <div class="nav_up">
         <nav>
            <ul>
            <li><a href="/myproject/new/index.php"class="up_nav">LOGOUT</a></li>
            <li><a href="/myproject/new/gallary.php" class="d_nav">PHOTOGALLARY</a></li>
               <li><a href="/myproject/new/faqs.php" class="up_nav">FAQs</a></li>
               <li><a href="/myproject/new/feedback.php" class="up_nav">FEEDBACK</a></li>
               <li><a href="/myproject/new/downloads.php"class="up_nav">DOWNLOADS</a></li>
            </ul>
         </nav>
      </div>
      <div class="upp_nav"></div>
      <div class="heading">
         <img src="logo.png" alt="Srijan logo" class="logo">
         <div class="school_name"><b>SRIJAN VIDYAPEETH</b></div>
         <img src="img1.jpg" alt="image" class="image_header">
      </div>
      <div class="down_nav"></div>
   </header>
</head>

<body>
   <div class="main_menu">
      <nav>
         <div class="dropdown">
            <button onclick="window.location.href='/myproject/new/main_about.php'" class="dropbtn">ABOUT US</button>
            <div class="dropdown-content">
               <a href="/myproject/new/history.php">HISTORY</a>
               <a href="/myproject/new/vision.php">VISION & MISSION</a>
               <a href="/myproject/new/management.php">MANAGEMENT</a>
               <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
            </div>
         </div>


         <div class="dropdown">
            <button onclick="window.location.href='/myproject/new/school_education.php'" class="dropbtn">SCHOOL EDUCATION</button>
            <div class="dropdown-content">
            <a href="/myproject/new/school_about.php">ABOUT US</a>
               <a href="/myproject/new/features.php">FEATURES</a>
               <a href="/myproject/new/courses.php">COURSES & SCHEMES</a>
               <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
               <a href="/myproject/new/faculty.php">FACULTY &STAFFS</a>
               <a href="/myproject/new/school_activities.php">SCHOOL ACTIVITIES</a>
               <a href="/myproject/new/school_admissions.php">ADMISSIONS</a>
               <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
               <a href="/myproject/new/contact.php">CONTACT US</a>
            </div>
         </div>


         <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/higher_education.php'" class="dropbtn">HIGHER EDUCATION</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/calender.php">ACADEMIC CALENDERS</a>
                 <a href="/myproject/new/ug.php">UG PROGRAMMES</a>
                 <a href="/myproject/new/pg.php">PG PROGRAMMES</a>
                 <a href="/myproject/new/phd.php">PH.D. PROGRAMMES</a>
                 <a href="/myproject/new/certificate.php">CERTIFICATE & DIPLOMA PROGRAMMES</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
              </div>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_admissions.php'" class="dropbtn">ADMISSIONS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/school_education.php">SCHOOL EDUCATION</a>
                 <a href="/myproject/new/higher_education.php">HIGHER EDUCATION</a>
                 <a href="/myproject/new/rule.php">CAMPUS RULES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/finance.php'" class="dropbtn">FINANCIAL ASSISTANCE</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/scholar.php">SCHOLARSHIPS</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/library.php'" class="dropbtn">LIBRARY</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/lib.php">LIBRARY</a>
                 <a href="/myproject/new/online.php">ONLINE RESOURCES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/exam.php'" class="dropbtn">EXAMINATION</button>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/sports.php'" class="dropbtn">SPORTS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/indoor.php">INDOOR</a>
                 <a href="/myproject/new/outdoor.php">OUTDOOR</a>
              </div>
           </div>
  
      </nav>
   </div>


   <div class="main_content">

      <h2>About Us</h2>
      <p>
         Banasthali Vidyapith is a fully residential women's higher education institute which offers an integrated
         system extending from the primary to the Ph.D. level.

         It was on October 6, 1935 that Smt. Ratan Shastri and Pandit Hiralal Shastri founded Banasthali to fill up the
         vacuum caused by the sudden death of their highly talented and promising daughter Shantabai. They had high
         expectations that she would work for women's cause when she would grow up. But destiny ordained otherwise.
         Thus, Banasthali owes its existence neither to the zeal of an educationist, nor to that of a social reformer.
         It is also not the creation of a Philanthropist's purse. It has arisen like the fabled phoenix from the ashes
         of a blossoming flower Shantabai.

         Banasthali is one of the five higher education institute in India meant exclusively for Women. Over these
         seventy five years Banasthali has developed into a National Centre for women's education. Banasthali's
         educational programme aims at an all-round development of the student's personality. To achieve its objective
         of 'synthesis of spiritual values and scientific achievements of the East and the West', it has evolved
         Five-fold Educational Programme (Panchmukhi Shiksha) comprising of the following aspects : (i) Physical, (ii)
         Practical, (iii) Aesthetic, (iv) Moral and (v) Intellectual. This way the students develop an integrated and
         balanced personality.

         The rural ambience of Banasthali Vidyapith is very conducive for promoting the ideology of simple living, and
         for imbibing and internalizing the values of self-reliance and tolerance. Following the philosophy of the
         balanced Panchmukhi system of education, the institute provides ample opportunities for integrated development
         of the personality. The stress on the positive aspects of the Indian heritage has resulted in a climate which
         has contributed significantly to the task of the upliftment of women to enable them to take on leadership roles
         with confidence.

         This institute has made full use of the autonomy provided under the deemed university status and has
         innovatively restructured the courses offered which include subjects ranging from the traditional as well tthe
         emerging areas to the highest level of research (leading to the doctoral degree). Banasthali has been
         accredited by National Assessment and Accreditation Council (NAAC) with 'A' Grade (Five star Rating).
         Banasthali is a recipient of SANTBAL Award in the year 2000 for the services in the field of all round
         education of women.
      </p>
   </div>
</body>
</html>