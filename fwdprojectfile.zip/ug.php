<!DOCTYPE html>
<html lang="en">

<head>

    <title>Srijan vidhyapeeth</title>
    <link href="ug.css" rel="stylesheet" type="text/css">

    <header>
        <div class="nav_up">
            <nav>
                <ul>
                <li><a href="/myproject/new/index.php"class="up_nav">LOGOUT</a></li>
                <li><a href="/myproject/new/gallary.php" class="d_nav">PHOTOGALLARY</a></li>
               <li><a href="/myproject/new/faqs.php" class="up_nav">FAQs</a></li>
               <li><a href="/myproject/new/feedback.php" class="up_nav">FEEDBACK</a></li>
               <li><a href="/myproject/new/downloads.php"class="up_nav">DOWNLOADS</a></li>
                </ul>
            </nav>
        </div>
        <div class="upp_nav"></div>
        <div class="heading">
            <img src="logo.png" alt="Srijan logo" class="logo">
            <div class="school_name"><b>SRIJAN VIDYAPEETH</b></div>
            <img src="img1.jpg" alt="image" class="image_header">
        </div>
        <div class="down_nav"></div>
    </header>
</head>

<body>
<div class="main_menu">
        <nav>
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/main_about.php'" class="dropbtn">ABOUT US</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/history.php">HISTORY</a>
                 <a href="/myproject/new/vision.php">VISION & MISSION</a>
                 <a href="/myproject/new/management.php">MANAGEMENT</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_education.php'" class="dropbtn">SCHOOL EDUCATION</button>
              <div class="dropdown-content">
              <a href="/myproject/new/school_about.php">ABOUT US</a>
                 <a href="/myproject/new/features.php">FEATURES</a>
                 <a href="/myproject/new/courses.php">COURSES & SCHEMES</a>
                 <a href="/myproject/new/five_fold.php">FIVE FOLD EDUCATION</a>
                 <a href="/myproject/new/faculty.php">FACULTY &STAFFS</a>
                 <a href="/myproject/new/school_activities.php">SCHOOL ACTIVITIES</a>
                 <a href="/myproject/new/school_admissions.php">ADMISSIONS</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
                 <a href="/myproject/new/contact.php">CONTACT US</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/higher_education.php'" class="dropbtn">HIGHER EDUCATION</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/calender.php">ACADEMIC CALENDERS</a>
                 <a href="/myproject/new/ug.php">UG PROGRAMMES</a>
                 <a href="/myproject/new/pg.php">PG PROGRAMMES</a>
                 <a href="/myproject/new/phd.php">PH.D. PROGRAMMES</a>
                 <a href="/myproject/new/certificate.php">CERTIFICATE & DIPLOMA PROGRAMMES</a>
                 <a href="/myproject/new/fee.php">FEE SUBMISSION</a>
              </div>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/school_admissions.php'" class="dropbtn">ADMISSIONS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/school_education.php">SCHOOL EDUCATION</a>
                 <a href="/myproject/new/higher_education.php">HIGHER EDUCATION</a>
                 <a href="/myproject/new/rule.php">CAMPUS RULES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/finance.php'" class="dropbtn">FINANCIAL ASSISTANCE</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/scholar.php">SCHOLARSHIPS</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/library.php'" class="dropbtn">LIBRARY</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/lib.php">LIBRARY</a>
                 <a href="/myproject/new/online.php">ONLINE RESOURCES</a>
              </div>
           </div>
  
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/exam.php'" class="dropbtn">EXAMINATION</button>
           </div>
  
           <div class="dropdown">
              <button onclick="window.location.href='/myproject/new/sports.php'" class="dropbtn">SPORTS</button>
              <div class="dropdown-content">
                 <a href="/myproject/new/indoor.php">INDOOR</a>
                 <a href="/myproject/new/outdoor.php">OUTDOOR</a>
              </div>
           </div>
        
        </nav>
  
     </div>
  
    <div class="main_content">
       <h2>Under Graduate Programmes</h2>
     <p>Admission to all three years undergraduate degree programmes of Banasthali Vidyapith is based on merit of Senior Secondary Certificate Examination (for the purpose of preparation of merit the marks from various Boards are normalized) except for admission to B.Ed. where Aptitude Tests are conducted.
        <br>
        <br>
        <b>Duration :</b> B.A. / B.Sc.(Mathematics) / B.Sc(Bio Science) / B.Sc(Bio Technology) /B.Sc (Geology) / B.Sc. (Home Science) / B.Sc. (Aviation Science) / BCA / BBA / B.Com. - 3 Years (six semester), B.Ed. - 2 Years,   B.A. (B.Ed.) / B.Sc.(B.Ed.) - 4 Years, B.A. LL.B. (I) /  B.Com. LL.B.(I)  / B.B.A. LL.B.(I) - 5 Years, B.Arch.- 5 Years.
     </p>
       <h4>Minimum Eligibility</h4>
       <p>
      <b>  B.A.  :</b> Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith as equivalent thereto with Arts/Science /Home-science.
<br><br>
<b>B.Sc. (Mathematics) :</b> 60% aggregate in Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith as equivalent thereto with Mathematics.
<br><br>
<b>
B.Sc.  (Bio Science) :</b> 55% aggregate in Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith as equivalent thereto with science Biology.
<br><br>
<b>
B.Sc. (Home Science) :</b> Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith as equivalent thereto with a minimum of 50% marks.

<br><br><b>
B.Com. (Bachelor of Commerce):</b> Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith as equivalent thereto in any stream.

<br><br><b>
BCA : </b>60% aggregate in Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith as equivalent thereto.

<br><br><b>
BBA :</b> Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith as equivalent thereto.

<br><br><b>
B.A. (B.Ed.)   :</b> 50% in 10+2 with Arts.

<br><br><b>
B.Ed.(B.Sc.) : </b>50% in 10+2 with Science
<br><br>
<strong>
NOTE : </strong>SC/ST candidates the minimum aggregate percentage required is 40% in all the courses above.
<br><br>
<b>
B.Tech. (Computer Science and Engineering/ Computer Science-Artificial Intelligence (CSAI)# / Electronics and Communication/ Electronics and Instrumentation/ Electrical and Electronics/ Information Technology/ Bio Technology/ Chemical Engineering/ Mechatronics) : </b>60% aggregate in 10+2 with Physics, Chemistry, Mathematics (PCM)
<br><br>
<b>B. Pharm. :</b> 60% aggregate in 10+2 with Physics, Chemistry, Biology (PCB) / Maths (PCM)
<br><br>
<strong>
NOTE :</strong> For SC/ST candidates the minimum eligibility is 40% aggregate in 10+2  with subject as above.
<br><br>
<b>
B.Ed. :</b> Female candidate with atleast 50% aggregate marks in their three years Bachelor's Degree/ or Master's Degree from Banasthali Vidyapith or a University recognized by Banasthali Vidyapith as equivalent thereto.
<br><br>
<strong>
NOTE : </strong> SC/ST candidates the minimum aggregate percentage required is 45% .
<br><br>
<b>
B.Sc. (Aviation Science) : </b>The candidates who have attained the age of 17 years and who have passed the Senior Secondary School Examination/ 12th examination conducted by State Board/ CBSE or any other examination recognized as equivalent thereto, irrespective of the stream. (Note: Students from non-Science background have to pass the Physics and Mathematics papers (of 12th standard) in their B.Sc. I year in addition to the core papers of B.Sc. (Aviation Science)).
<br><br>
<b>
B. Des. (Bachelor of Design):</b> 50% aggregate in Senior Secondary 10+2
<br><br>
<b>
B.A. (Journalism and Mass Communication): </b>50% aggregate in Senior Secondary 10+2
<br><br>
<b>B.A. (LL.B.) (I) / BBA (LL.B.) (I) / B.Com. (LL.B.) (I)</b>
   <br><br><strong>
Duration:</strong><br><br>
5 Years Course (Dual Degree) with semester scheme. No lateral exit is permissible by way of awarding the degree, splitting the integrated double degree course at any intermediate stage of programme.
<br><br>
<strong>Minimum Eligibility:</strong><br><br>
45% aggregate Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith  as equivalent thereto in any stream. The admission would be based on the merit of the qualifying examination.<br><br><strong>
Age: </strong> Less than 20 years as on July 08, 2022 (less than 22 years in case of Sc/ST/OBC/PH Category).
<br><br><strong>
B.Arch.<br><br>
Duration:</strong><br><br>
5 Years Course<br><br><strong>
Minimum Eligibility:</strong><br><br>
50% in aggregate in 10+2/ Senior Secondary School certificate examination with Science Mathematics. Additionally, the student will have to meet the minimum qualifying marks in National Aptitude Test in Architecture (NATA) examination (valid NATA score) as prescribed by the Council of Architecture for the corresponding year. 
<br><br><b>
B.Sc (Geology) :</b> Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith as equivalent thereto with science.  
<br><br><b>
B.Sc (Biotechnology) :</b> 55% aggregate in Senior Secondary School Certificate Examination of Banasthali or an examination recognized by Banasthali Vidyapith as equivalent thereto with science Biology.
<br><br>
 
<strong>
NOTE :
</strong><br><br>
The students opting for Drawing and Music have to pass an aptitude test.
<br><br>
Mathematics and Statistics can only be opted if the student has studied Mathematics as an elective at 10+2 level.
 </p>
</div>
</body>

</html>